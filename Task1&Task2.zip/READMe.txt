For tasks 1 and 2 refer to the projects section and open tasks accordingly

Git Repo: https://github.com/Eswarreddy12k/Ed-Spread-Project
Website: eswarreddyk.netlify.app